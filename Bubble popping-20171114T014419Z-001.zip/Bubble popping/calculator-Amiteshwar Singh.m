//
//  main.m
//  calc by Amiteshwar Singh- 12182200
//

#import <Foundation/Foundation.h>
typedef enum {
    c_NONE,
    c_ADD,
    c_SUB,
    c_MULT,
    c_DIV
} choice;


static int solve(NSArray *temp) {
    choice choice = c_NONE;
    NSMutableArray *higher_value=[NSMutableArray arrayWithObjects:@"", nil];
    int number=0;
    int result = 0;
    for (NSString *arg in temp) {
        
        
        if ( number!=0 && [higher_value[number-1] isEqualToString:@"/"]) {
            int cal =[higher_value[number-2] intValue] /[arg intValue];
            higher_value[number-2]=[NSString stringWithFormat:@"%d",cal];
            number=number-1;
            
        } else if (number!=0 && [higher_value[number-1] isEqualToString:@"x"]) {
            
            int cal =[higher_value[number-2] intValue] * [arg intValue];
            higher_value[number-2]=[NSString stringWithFormat:@"%d",cal];
            number=number-1;
            
            
        }else if (number!=0 && [higher_value[number-1] isEqualToString:@"%"]) {
            
            int cal =[higher_value[number-2] intValue] % [arg intValue];
            higher_value[number-2]=[NSString stringWithFormat:@"%d",cal];
            number=number-1;
            
            
        }
        
        
        
        
        else {
            higher_value[number]=arg;
            number=number+1;
        }
        
    }
    
    for(int i=0;i<number;i++)
    {
        if ([higher_value[i] isEqualToString:@"+"]) {
            choice = c_ADD;
            
        } else if ([higher_value[i] isEqualToString:@"-"]) {
            choice = c_SUB;
        } else {
            int value = [higher_value[i] intValue];
            switch(choice) {
                case c_SUB: result -= value; break;
                case c_ADD: result += value; break;
                case c_NONE: result = value; break;
                default: abort();
            }
            choice = c_NONE;
        }
        
    }
    return result;
}


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSMutableArray *temp = [NSMutableArray new];
        for (int i = 1; i < argc; i++)
            [temp addObject:@(argv[i])];
        
        NSLog(@"result = %d", solve(temp));

        
    }
    return 0;
}
